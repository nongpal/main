
import os
import tensorflow as tf
import tensorflow_hub as hub
import tensorflow_transform as tft
from keras.layers import *
from keras.metrics import *
from keras.callbacks import *
from keras.optimizers import *
from tfx.components.trainer.fn_args_utils import FnArgs

FEATURE_KEY = "Text"
LABEL_KEY = 'Label'
NUM_EPOCHS = 10

def transformed_name(key):
  return key + "_xf"

def gzip_reader_fn(filenames):
  return tf.data.TFRecordDataset(filenames, compression_type='GZIP')

def input_fn(file_pattern, tf_transform_output, epochs, baze = 64) -> tf.data.Dataset:

  transform_feature_spec = (tf_transform_output.transformed_feature_spec().copy())

  dataset = tf.data.experimental.make_batched_features_dataset(
      file_pattern = file_pattern,
      batch_size = baze,
      features = transform_feature_spec,
      reader = gzip_reader_fn,
      num_epochs = epochs,
      label_key = transformed_name(LABEL_KEY)
  )
  return dataset

vocab = 5000
length = 19

vect = TextVectorization(
    max_tokens = vocab,
    output_mode = 'int',
    output_sequence_length = length
)

emb_dim = 16

def modeling():
    input = tf.keras.Input(shape=(1,), name=transformed_name(FEATURE_KEY), dtype=tf.string)
    text_vectorized = vect(input)

    embd = Embedding(vocab, emb_dim, input_length=length, name='embedding')(text_vectorized)
    lstm1 = Bidirectional(LSTM(32))(embd)

    dense1 = Dense(16, 'relu')(lstm1)
    output = Dense(1, 'sigmoid')(dense1)

    model = tf.keras.Model(inputs=input, outputs=output)

    model.compile(
        optimizer = Adam(0.001),
        loss = 'binary_crossentropy',
        metrics = ['binary_accuracy']
    )

    model.summary()
    return model

def _get_serve_tf_examples_fn(model, tf_transform_output):

  model.tft_layer = tf_transform_output.transform_features_layer()

  @tf.function
  def serve_tf_examples_fn(serialized_ex):

    feature_spec = tf_transform_output.raw_feature_spec()

    feature_spec.pop(LABEL_KEY)

    parsed = tf.io.parse_example(serialized_ex, feature_spec)

    transformed_features = model.tft_layer(parsed)

    return model(transformed_features)

  return serve_tf_examples_fn

def run_fn(fn_args: FnArgs) -> None:

  log_dir = os.path.join(os.path.dirname(fn_args.serving_model_dir), 'logs')

  tenbor = TensorBoard(
      log_dir = log_dir,
      update_freq = 'batch'
  )

  es = EarlyStopping(
      monitor = 'val_binary_accuracy',
      mode = 'max',
      patience = 2,
      verbose = 1
  )

  mc = ModelCheckpoint(
      fn_args.serving_model_dir,
      mode = 'max',
      monitor = 'val_binary_accuracy',
      save_best_only = True
  )

  tf_transform_output = tft.TFTransformOutput(fn_args.transform_graph_path)

  train_set = input_fn(fn_args.train_files, tf_transform_output, NUM_EPOCHS)
  val_set = input_fn(fn_args.eval_files, tf_transform_output, NUM_EPOCHS)
  text_data = [j[0].numpy()[0] for j in [i[0][transformed_name(FEATURE_KEY)] for i in list(train_set)]]
  vect.adapt(text_data)

  model = modeling()

  model.fit(x = train_set,
            steps_per_epoch=fn_args.train_steps,
            validation_data = val_set,
            callbacks = [tenbor, es, mc],
            validation_steps = fn_args.eval_steps,
            epochs = NUM_EPOCHS)

  signature = {
      'serving_default' :
      _get_serve_tf_examples_fn(
          model,
          tf_transform_output
      ).get_concrete_function(tf.TensorSpec(shape = [None],
                                            dtype = tf.string,
                                            name = 'examples'))
  }
  model.save(fn_args.serving_model_dir, save_format = 'tf', signatures = signature)
