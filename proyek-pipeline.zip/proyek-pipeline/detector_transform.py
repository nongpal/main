
import tensorflow as tf

FEATURE_KEY = "Text"
LABEL_KEY = 'Label'

def transformed(key):
  return key + "_xf"

def preprocessing_fn(input):
  output = {}

  output[transformed(FEATURE_KEY)] = tf.strings.lower(input[FEATURE_KEY])
  output[transformed(LABEL_KEY)] = tf.cast(input[LABEL_KEY], tf.int64)

  return output
