Karena keterbatasan sumber daya komputasi (CPU laptop) saya, saya hanya bisa sampai dalam membuat file "Dockerfile" dan hanya bisa untul mem-build docker, tidak bisa untuk running.

Ketika saya hendak running muncul output seperti berikut:

/usr/bin/tf_serving_entrypoint.sh: line 4:     8 Illegal instruction     tensorflow_model_server --port=8500 --rest_api_port=${PORT} --model_name=${MODEL_NAME} --model_base_path=${MODEL_BASE_PATH}/${MODEL_NAME} "$@"